myString = "This is a string."
print(myString)
print(type(myString))

print(f"{myString} is of the data type {type(myString)}")

firstString = "water"
secondString = "fall"
print(f"{firstString} {secondString}")

name = input("What is your name?")
print(name)

color = input("What is your favorite color?")
animal = input("What is your favorite animal?")
print("{}, you like a {} {}!".format(name,color,animal))
print(f"{name}, you like a {color} {animal}!")
