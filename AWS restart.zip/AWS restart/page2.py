myFruitList = ["apple", "banana", "cherry"]
print(myFruitList)
print(type(myFruitList))
print(myFruitList[2])

myFinalAnswerTuple = ("apple", "banana", "pineapple")
print(myFinalAnswerTuple)
print(type(myFinalAnswerTuple))
print(myFinalAnswerTuple[0])

myFruitSet = {"apple", "banana", "cherry"}
print(myFruitSet)
print(type(myFruitSet))

myFavoriteFruitDictionary = {
  "Akua" : 1,
  "Saanvi" : "banana",
  "Paulo" : "pineapple"
}
print(myFavoriteFruitDictionary)
print(f"\n {myFavoriteFruitDictionary["Akua"]}")

